package com.example.aws.blogapp.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.aws.blogapp.R;

public class web extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);
    }
}
